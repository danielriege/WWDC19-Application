//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import UIKit
import PlaygroundSupport

//#-end-hidden-code
//#-end-editable-code
/*:
 # Fundamentals
 
 You probably have heard the word Blockchain in context of [Bitcoin](glossary://bitcoin) etc. before.
 But what is a Blockchain?
 A Blockchain is nothing more than a chain of blocks. So what is a Block then. It is some sort of thing which can contain information like for instance the date this thing was created. If you are familiar with the concepts of [object-oriented programming](glossary://oop), your brain shall ring bells by now. A Block is nothing more than an object! So, for now on, when we hear the word blockchain we think of an array of objects.
```
class Block {
    var timestamp: Date
    
    init() {
        self.timestamp = Date()
    }
}

var blockchain: [Block]
```
 ## But what does a block besides a date actually contain now?
 It holds a [transaction](glossary://transaction). Bitcoin blocks actually hold more than one transaction. Nevertheless, to simply things, our blocks will only contain one transaction.
 > We're using `var` instead of `let` here to demonstrate tampering later on since the data is stored in a text format and could also be changed.
 */
class Transaction {
    var from: String
    var to: String
    var amount: Double
    
    init(sender: String, receiver: String, amount: Double) {
        self.from = sender
        self.to = receiver
        self.amount = amount
    }
}

class Block {
    var timestamp: Date
    var transaction: Transaction
    
    init(transaction: Transaction) {
        self.transaction = transaction
        self.timestamp = Date()
    }
}
var blockchain = [Block]() // creating an empty blockchain
/*:
 So if we want to send person B 50 coins, we create an instance of a  transaction and provide it with our information.
 */
var firstTransaction = /*#-copy-source(tx1)*/Transaction(sender: /*#-editable-code */"Person A"/*#-end-editable-code */, receiver: /*#-editable-code */"Person B"/*#-end-editable-code */, amount:/*#-editable-code */ 50.0 /*#-end-editable-code */) /*#-end-copy-source*/
/*:
 To clarify things, when we say that we send someone some coins of whatever cryptocurrency, we don’t actually have these coins and ‘send’ them. We just create a transaction object to let everyone on the network know we gave Person B some coins. So, when we want to check our balance, the computer will sum all transactions including you and calculate your balance that way, every time. Your balance won’t be stored as a number.
 
 Now, if we have created our transaction, we then create a block which holds this transactions and add this block to the blockchain.
 */
var firstBlock = Block(transaction: firstTransaction)

blockchain.append(firstBlock)
/*:
 As you may know, cryptocurrencies are working on a [decentralized system](glossary://decantralized-System). So everyone on the network will get a copy of this excact blockchain (with every block and therefore every transaction) and will receive updates when a block was added like ours now. Unfortunately we won't look deeper into this topic but how the blockchain technology works. Continue with the [next page](@next) to learn more about the security of our blockchain.
 */
//#-hidden-code
func showBlockchain(_ blockchain: [Block]) {
    var translatedArray = [[String: String]]()
    for block in blockchain {
        let blockDict: [String: String] = ["from": block.transaction.from,
                                           "amount": String(block.transaction.amount),
                                           "to": block.transaction.to,
                                           "timestamp": String(block.timestamp.timeIntervalSince1970),
                                           ]
        translatedArray.append(blockDict)
    }
    sendValue(translatedArray)
}

sendValue("!genisis")

showBlockchain(blockchain)
//#-end-hidden-code

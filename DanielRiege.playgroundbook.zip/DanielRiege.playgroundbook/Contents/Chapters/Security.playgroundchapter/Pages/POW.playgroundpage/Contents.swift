//#-hidden-code
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import UIKit
import PlaygroundSupport

sendValue("!genisis")

class Transaction {
    var from: String
    var to: String
    var amount: Double
    
    init(sender: String, receiver: String, amount: Double) {
        self.from = sender
        self.to = receiver
        self.amount = amount
    }
}
//#-end-hidden-code
/*:
# Proof of Work
As you have seen on the previous page, it is still possible to hack our blockchain. We just need to recalculate all hashes that are coming after our hacked block. To fix this problem we will use **proof of work**. With that you need computing power to calculate the hash of a block which makes it harder for a hacker.
 */
class Block {
    var timestamp: Date
    var transaction: Transaction
    var hash: String
    var prevHash: String
    var pow: Int
    
    init(transaction: Transaction) {
        self.pow = 0
        self.transaction = transaction
        self.timestamp = Date()
        // If our blockchain is empty, the first block will be the Genisis
        if blockchain.count > 0 {
            // get the hash of last block in the array to use as previous
            self.prevHash = blockchain[blockchain.count-1].hash
        } else {
            self.prevHash = "" // Genisis
        }
        //#-hidden-code
        self.hash = ""
        //#-end-hidden-code
        self.hash = calculateHash()
    }
/*:
How do we make it harder for a computer to generate a block? Below you see something like `let difficulty = "00"`. This needs to be the prefix for our calculated hash. Since we don't know what we need to add to our string, from which the hash will be calculated, to accomplish our prefix purpose, we will brute force it. This means we add an integer to our `calculateHash()` method which will increase every try until we get our prefix. This integer is called `pow` and is initialized with `0` above.
> This process is also called mining. In the Bitcoin network, the miner, who provides the computing power to create new blocks, will be rewarded for that by the system. This is the 'mining for Bitcoins'.
 */
    func calculateHash() -> String {
        return (transaction.from + transaction.to + String(transaction.amount) + prevHash + String(pow)).toHash()
    }
}
//#-hidden-code

class Genisis: Block {
    init() {
        super.init(transaction: Transaction(sender: "", receiver: "", amount: 0.0))
    }
}

func showBlockchain(_ blockchain: [Block]) {
    var translatedArray = [[String: String]]()
    for block in blockchain {
        if block is Genisis {
            sendValue("genisis")
            continue
        }
        let blockDict: [String: String] = ["from": block.transaction.from,
                                           "amount": String(block.transaction.amount),
                                           "to": block.transaction.to,
                                           "timestamp": String(block.timestamp.timeIntervalSince1970),
                                           "hash": block.hash,
                                           "prevHash": block.prevHash,
                                           "pow": String(block.pow)]
        translatedArray.append(blockDict)
    }
    sendValue(translatedArray)
}
//#-end-hidden-code
var blockchain = [Block]()
    //#-hidden-code
{
    didSet {
        showBlockchain(blockchain)
    }
}
//#-end-hidden-code

extension Block {
    func mine() {
        repeat {
            pow = pow + 1
            hash = calculateHash()
        } while !hash.hasPrefix(difficulty)
    }
}

let difficulty = /*#-editable-code*/"00"/*#-end-editable-code*/

/*:
 In our `isValid()` method we added another if statement which checks if our hash has the right prefix.
 */
extension Block {
    func isValid() -> Bool {
        if self is Genisis { return true } // Genisis is always valid
        
        if !self.hash.hasPrefix(difficulty) { return false } // Unvalid Hash
        
        if self.prevHash == "" { return false } // Block is not part of blockchain
        
        if blockchain[heightOf(self)-1].calculateHash() != self.prevHash { return false } // Our prevHash is not equal to hash of previuous block.
        
        if self.hash != calculateHash() { return false } // Block was tampered
        
        return true
    }
}

//#-hidden-code
func heightOf(_ block: Block) -> Int {
    return blockchain.firstIndex(where: {$0.hash == block.hash}) ?? blockchain.count
}
//#-end-hidden-code
/*:
Well, our chain is small and the difficulty is easy so it won't be hard to recalculate all hashes after we hacked one block. Although, Bitcoin blocks need to have 18 zeros as prefix. The chance to find the right hash on the first try is 1 / 16^18. You already see, it will take a loot of time and energy as well.
 */

//#-editable-code
blockchain.append(Genisis())

let transaction1 = Transaction(sender: "Person A", receiver: "Person B", amount: 25.0)
let block1 = Block(transaction: transaction1)
block1.mine()
block1.isValid()
blockchain.append(block1)

let transaction2 = Transaction(sender: "Person B", receiver: "Person A", amount: 50.0)
let block2 = Block(transaction: transaction2)
block2.mine()
block2.isValid()
blockchain.append(block2)


//#-end-editable-code
//: [Next](@next)
//#-hidden-code

func showBlockchainWithCheck(_ blockchain: [Block]) {
    var translatedArray = [[String: String]]()
    for block in blockchain {
        if block is Genisis {
            continue
        }
        let blockDict: [String: String] = ["from": block.transaction.from,
                                           "amount": String(block.transaction.amount),
                                           "to": block.transaction.to,
                                           "timestamp": String(block.timestamp.timeIntervalSince1970),
                                           "hash": block.hash,
                                           "prevHash": block.prevHash,
                                           "check": String(block.isValid()),
                                           "pow": String(block.pow)]
        translatedArray.append(blockDict)
    }
    sendValue(translatedArray)
}
showBlockchainWithCheck(blockchain)
//#-end-hidden-code

//#-hidden-code
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import UIKit
import PlaygroundSupport

//#-end-hidden-code
/*:
 # Implementing Hashing
 The idea is to add a method to the class of `Block` that verifys that the block was not hacked. To do so, we will calculate a hash code of all values.
 */
//#-hidden-code
class Transaction {
    var from: String
    var to: String
    var amount: Double
    
    init(sender: String, receiver: String, amount: Double) {
        self.from = sender
        self.to = receiver
        self.amount = amount
    }
}
//#-end-hidden-code
class Block {
    var timestamp: Date
    var transaction: Transaction
    var hash: String
    var prevHash: String
    
    func calculateHash() -> String {
        return (transaction.from + transaction.to + String(transaction.amount) + prevHash).toHash()
    }
/*:
 To verify this block, we call `calculateHash()` in the `init()` method and store it in the `hash` attribute. Later we just need to call `calculateHash()` again, like everytime a block will be added to the blockchain, and then we will compare that with the `hash` attribute to see if they are equal. Because if it doesn't match, something like the amount, sender or receiver was changed. By that we can always make sure that our blockchain is valid.
     
# Linked List
     
But as you see, we have another attribute called `prevHash` which is the hash code of the block before ours in the array. So every block additionaly knows the hash code of the previous block. Our blockchain array is like a singly linked list. If you now change a value of a transaction, the block becomes invalid and with that every other block on the blockchain too, because they are all linked together and we use the `prevHash` in the `calculateHash()` method.
     
Since we are now using the concept of a [singly linked list](glossary://sll), we need a first node which is 'empty'. Every node in our blockchain array knows the previuous node (by the hash) and the first node will have no previous hash. To make things easier, this first node/block will not hold a referance to a transaction and shall be created when our blockchain will be initialized.
> In Bitcoin, this first node is called Genisis. We will use the same name.
 */
    
    init(transaction: Transaction) {
        self.transaction = transaction
        self.timestamp = Date()
        // If our blockchain is empty, the first block will be the Genisis
        if blockchain.count > 0 {
            // get the hash of last block in the array to use as previous
            self.prevHash = blockchain[blockchain.count-1].hash
        } else {
            self.prevHash = "" // Genisis
        }
        //#-hidden-code
        self.hash = ""
        //#-end-hidden-code
        self.hash = calculateHash()
    }
    
    
    func isValid() -> Bool {
        if self is Genisis { return true } // Genisis is always valid
        
        if self.prevHash == "" { return false } // Block is not part of blockchain
        
        if blockchain[heightOf(self)-1].calculateHash() != self.prevHash { return false } // Block holds wrong hash of previous block.
        
        if self.hash != calculateHash() { return false } // Block was tampered
        
        return true
    }
}

/// Returns the index of block in the blockchain. The index is also called height in terms of blockchain.
func heightOf(_ block: Block) -> Int {
    return blockchain.firstIndex(where: {$0.hash == block.hash}) ?? blockchain.count
}

/// Genisis is a subclass of Block which makes it easier to test if a block is the Genisis
class Genisis: Block {
    init() {
        super.init(transaction: Transaction(sender: "", receiver: "", amount: 0.0))
    }
}
/*:
 Now this is some code to understand. Take your time. Afterwards, try to hack the blockchain by changing the amount of `block1` and keep the blockchain valid.
 */
var blockchain = [Block]()
blockchain.append(Genisis())

let transaction1 = Transaction(sender: "Person A", receiver: "Person B", amount: 25.0)
let block1 = Block(transaction: transaction1)
block1.isValid()
blockchain.append(block1)

let transaction2 = Transaction(sender: "Person B", receiver: "Person A", amount: 50.0)
let block2 = Block(transaction: transaction2)
block2.isValid()
blockchain.append(block2)
//#-editable-code

block1.transaction.amount = 500.0

//#-end-editable-code
/*:
 To fix this problem, go on to the [next page](@next). There you'll learn a conecpt that is also used by Bitcoin.
 */
//#-hidden-code
sendValue("!genisis")
func showBlockchain(_ blockchain: [Block]) {
    var translatedArray = [[String: String]]()
    for block in blockchain {
        if block is Genisis {
            sendValue("genisis")
            continue
        }
        let blockDict: [String: String] = ["from": block.transaction.from,
                                               "amount": String(block.transaction.amount),
                                               "to": block.transaction.to,
                                               "timestamp": String(block.timestamp.timeIntervalSince1970),
                                               "hash": block.hash,
                                               "prevHash": block.prevHash,
                                               "check": String(block.isValid())]
        translatedArray.append(blockDict)
    }
    sendValue(translatedArray)
}

showBlockchain(blockchain)
//#-end-hidden-code

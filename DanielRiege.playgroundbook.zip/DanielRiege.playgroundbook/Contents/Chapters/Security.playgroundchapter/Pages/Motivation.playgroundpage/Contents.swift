//#-hidden-code
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import UIKit
import PlaygroundSupport

//#-end-hidden-code
/*:
 # Motivation
Right now we can easily hack our transaction by changing the amount afterwards.
 */
//#-hidden-code
class Transaction {
    var from: String
    var to: String
    var amount: Double
    
    init(sender: String, receiver: String, amount: Double) {
        self.from = sender
        self.to = receiver
        self.amount = amount
    }
}

class Block {
    var timestamp: Date
    var transaction: Transaction
    
    init(transaction: Transaction) {
        self.transaction = transaction
        self.timestamp = Date()
    }
}
var blockchain = [Block]()
//#-end-hidden-code
var firstTransaction = Transaction(sender: /*#-editable-code */"Person A"/*#-end-editable-code */, receiver: /*#-editable-code */"Person B"/*#-end-editable-code */, amount:/*#-editable-code */ 50.0 /*#-end-editable-code */)
var firstBlock = Block(transaction: firstTransaction)

blockchain.append(firstBlock)

firstTransaction.amount = /*#-editable-code*/ 5000.0 /*#-end-editable-code*/
/*:
 If you now run the code, you'll see that the amount of the transaction has actually changed. Let's say someone sent us 50 coins. With this implementation we could change that amount to 5000 coins. Good for us, but bad for the sender.
 To prevent that from happening, all blockchains are using [hashing algorithms](glossary://hashing) and many are using the [SHA256](glossary://sha256) algorithm, so we will do the same.
 > In this playground the class of `String` has a method called `toHash()` which calculates the hash value (SHA256) of its string. It was implemented using the [CommonCrypto](glossary://cc) Library.
 First things first, to ground your understaning of hash functions we will use an example.
 */
//#-editable-code
let helloWorldString = "Hello, World!"
let hashOfHelloWorld = helloWorldString.toHash() // Use the inspector to see the hash code

let differentString = "Hello, WWDC!"
let differentHash = differentString.toHash()

differentHash == hashOfHelloWorld
/*:
 As you can see, they are not equal. But we can hash our first string again and it delivers the same hash code as the first time.
 */
helloWorldString.toHash() == hashOfHelloWorld
//#-end-editable-code
//#-hidden-code
func showBlockchain(_ blockchain: [Block]) {
    var translatedArray = [[String: String]]()
    for block in blockchain {
        let blockDict: [String: String] = ["from": block.transaction.from,
                                           "amount": String(block.transaction.amount),
                                           "to": block.transaction.to,
                                           "timestamp": String(block.timestamp.timeIntervalSince1970),
                                           ]
        translatedArray.append(blockDict)
    }
    sendValue(translatedArray)
}

sendValue("!genisis")

showBlockchain(blockchain)
//#-end-hidden-code
/*:
 On the [next page](@next) you will learn how this hashing algorithm enhances the security of our blockchain.
 */



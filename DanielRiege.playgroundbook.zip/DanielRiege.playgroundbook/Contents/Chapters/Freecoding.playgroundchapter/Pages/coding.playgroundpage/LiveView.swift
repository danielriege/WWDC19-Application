import UIKit
import PlaygroundSupport

let vc = instantiateLiveView()
PlaygroundPage.current.liveView = vc

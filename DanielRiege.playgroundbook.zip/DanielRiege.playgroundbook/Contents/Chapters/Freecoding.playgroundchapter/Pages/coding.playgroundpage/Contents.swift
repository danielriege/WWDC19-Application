//#-hidden-code
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import UIKit
import PlaygroundSupport

sendValue("!genisis")

//#-end-hidden-code
/*:
 # Free Coding
 Hopefully you have a better understanding of blockchain and cryptocurrencies by now. This is the time where you can play around with the whole code and maybe add some features like calculating the balance for a person.
 */
//#-editable-code
let difficulty = "00"

class Transaction {
    var from: String
    var to: String
    var amount: Double
    
    init(sender: String, receiver: String, amount: Double) {
        self.from = sender
        self.to = receiver
        self.amount = amount
    }
}

class Block {
    var timestamp: Date
    var transaction: Transaction
    var hash: String
    var prevHash: String
    var pow: Int
    
    init(transaction: Transaction) {
        self.pow = 0
        self.transaction = transaction
        self.timestamp = Date()
        // If our blockchain is empty, the first block will be the Genisis
        if blockchain.count > 0 {
            // get the hash of last block in the array to use as previous
            self.prevHash = blockchain[blockchain.count-1].hash
        } else {
            self.prevHash = "" // Genisis
        }
        self.hash = "" // To have all attributes initialized first.
        self.hash = calculateHash()
    }
    
    func calculateHash() -> String {
        return (transaction.from + transaction.to + String(transaction.amount) + prevHash + String(pow)).toHash()
    }
    
    func mine() {
        repeat {
            pow = pow + 1
            hash = calculateHash()
        } while !hash.hasPrefix(difficulty)
    }
    
    func isValid() -> Bool {
        if self is Genisis { return true } // Genisis is always valid
        
        if !self.hash.hasPrefix(difficulty) { return false } // Unvalid Hash
        
        if self.prevHash == "" { return false } // Block is not part of blockchain
        
        if blockchain[heightOf(self)-1].calculateHash() != self.prevHash { return false } // Our prevHash is not equal to hash of previuous block.
        
        if self.hash != calculateHash() { return false } // Block was tampered
        
        return true
    }
}

func heightOf(_ block: Block) -> Int {
    return blockchain.firstIndex(where: {$0.hash == block.hash}) ?? blockchain.count
}

class Genisis: Block {
    init() {
        super.init(transaction: Transaction(sender: "", receiver: "", amount: 0.0))
    }
}

//#-end-editable-code
//#-hidden-code
func showBlockchain(_ blockchain: [Block]) {
    var translatedArray = [[String: String]]()
    for block in blockchain {
        if block is Genisis {
            sendValue("genisis")
            continue
        }
        let blockDict: [String: String] = ["from": block.transaction.from,
                                           "amount": String(block.transaction.amount),
                                           "to": block.transaction.to,
                                           "timestamp": String(block.timestamp.timeIntervalSince1970),
                                           "hash": block.hash,
                                           "prevHash": block.prevHash,
                                           "check": String(block.isValid()),
                                           "pow": String(block.pow)]
        translatedArray.append(blockDict)
    }
    sendValue(translatedArray)
}
//#-end-hidden-code
var blockchain = [Block]()
    //#-hidden-code
    {
    didSet {
        showBlockchain(blockchain)
    }
}
//#-end-hidden-code
//#-editable-code

blockchain.append(Genisis())

let transaction1 = Transaction(sender: "Person A", receiver: "Person B", amount: 25.0)
let block1 = Block(transaction: transaction1)
block1.mine()
block1.isValid()
blockchain.append(block1)

let transaction2 = Transaction(sender: "Person B", receiver: "Person A", amount: 50.0)
let block2 = Block(transaction: transaction2)
block2.mine()
block2.isValid()
blockchain.append(block2)


//#-end-editable-code
//#-hidden-code

showBlockchain(blockchain)
//#-end-hidden-code

//
//  Created by Daniel Riege on 16.03.19.
//

import UIKit
import PlaygroundSupport
import Foundation
import CommonCrypto
import Security


/// Instantiates a new instance of a live view.
///
/// By default, this loads an instance of `LiveViewController` from `LiveView.storyboard`.
public func instantiateLiveView() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "LiveView", bundle: nil)

    guard let viewController = storyboard.instantiateInitialViewController() else {
        fatalError("LiveView.storyboard does not have an initial scene; please set one or update this function")
    }

    guard let liveViewController = viewController as? LiveViewController else {
        fatalError("LiveView.storyboard's initial scene is not a LiveViewController; please either update the storyboard or this function")
    }
    return liveViewController
}

public func sendValue(_ value: PlaygroundValueConvertible) {
    let page = PlaygroundPage.current
    let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy
    proxy.send(value.asPlaygroundValue())
}

var blue: UIColor {
    return UIColor(displayP3Red: 0.0, green: 122/255.0, blue: 1.0, alpha: 1.0)
}

public protocol PlaygroundValueConvertible {
    func asPlaygroundValue() -> PlaygroundValue
}

extension String: PlaygroundValueConvertible {
    public func asPlaygroundValue() -> PlaygroundValue {
        return PlaygroundValue.string(self)
    }
}

extension Array: PlaygroundValueConvertible {
    public func asPlaygroundValue() -> PlaygroundValue {
        var playgroundValueArray = [PlaygroundValue]()
        for element in self {
            if let valueElement = element as? PlaygroundValueConvertible {
                playgroundValueArray.append(valueElement.asPlaygroundValue())
            } else {
                fatalError("\(element) is not PlaygroundValueConvertible")
            }
        }
        return PlaygroundValue.array(playgroundValueArray)
    }
}

extension Dictionary: PlaygroundValueConvertible where Key == String {
    public func asPlaygroundValue() -> PlaygroundValue {
        var playgroundValueDict = [String: PlaygroundValue]()
        for (key, value) in self {
            if let playgroundValue = value as? PlaygroundValueConvertible {
                playgroundValueDict[key] = playgroundValue.asPlaygroundValue()
            } else {
                fatalError("\(value) is not PlaygroundValueConvertible")
            }
        }
        return PlaygroundValue.dictionary(playgroundValueDict)
    }
}

public extension String {
    public func toHash() -> String {
        guard let messageData = self.data(using:String.Encoding.utf8) else {
            return ""
        }
        var digestData = Data(count: Int(CC_SHA256_DIGEST_LENGTH))
        
        _ = digestData.withUnsafeMutableBytes {digestBytes in
            messageData.withUnsafeBytes {messageBytes in
                CC_SHA256(messageBytes, CC_LONG(messageData.count), digestBytes)
            }
        }
        return digestData.base64EncodedString()
    }
}

func generatePrivateKey() -> SecKey? {
    let attributes: [String: Any] =
        [kSecAttrKeyType as String:            kSecAttrKeyTypeRSA,
         kSecAttrKeySizeInBits as String:      2048
    ]
    
    var error: Unmanaged<CFError>?
    if let privateKey = SecKeyCreateRandomKey(attributes as CFDictionary, &error) {
        return privateKey
    }
    return nil
}

func getPublicKey(privateKey: SecKey) -> SecKey? {
    if let publicKey = SecKeyCopyPublicKey(privateKey) {
        return publicKey
    }
    return nil
}

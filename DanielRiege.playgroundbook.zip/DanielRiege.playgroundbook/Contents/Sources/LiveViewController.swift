//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An auxiliary source file which is part of the book-level auxiliary sources.
//  Provides the implementation of the "always-on" live view.
//

import UIKit
import PlaygroundSupport

public class LiveViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    @IBOutlet weak var tableView: UITableView!
    
    var blockchain = [[String: String]]()
    
    let maxCellHeight: CGFloat = 240.0
    let minCellHeight: CGFloat = 88.0
    
    /// Flags
    var genisis = false
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.reloadData()
        
        if #available(iOS 11.0, *) {
            // to make every block completly visible
            //self.additionalSafeAreaInsets = UIEdgeInsets(top: 0.0, left: 0.0, bottom: 100.0, right: 0.0)
        }
    }
    
    /// If Genisis block is created by user, the header should be displayed.
    public func setGenisisFlag(hasFlag: Bool) {
        genisis = hasFlag
        tableView.reloadData()
    }
    
    public func receive(_ message: PlaygroundValue) {
        // Implement this method to receive messages sent from the process running Contents.swift.
        // This method is *required* by the PlaygroundLiveViewMessageHandler protocol.
        // Use this method to decode any messages sent as PlaygroundValue values and respond accordingly.
        switch message {
        case .string(let string): processCommand(com: string)
        case .array(let array): parseBlockchain(array: array)
        default: break
        }
    }
    
    private func processCommand(com: String) {
        switch com {
        case "genisis": setGenisisFlag(hasFlag: true)
        case "!genisis": setGenisisFlag(hasFlag: false)
        default: break
        }
    }
    
    private func parseBlockchain(array: [PlaygroundValue]) {
        var blockchainArray = [[String: String]]()
        for element in array {
            var blockDict = [String: String]()
            switch element {
            case .dictionary(let block):
                for (key, value) in block {
                    switch value {
                    case .string(let stringValue):
                        blockDict[key] = stringValue
                    default: break
                    }
                }
            default: break
            }
            blockchainArray.append(blockDict)
        }
        self.blockchain = blockchainArray
        self.tableView.reloadData()
    }
}

extension LiveViewController: UITableViewDelegate, UITableViewDataSource {
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return blockchain.count
    }
    
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    public func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if genisis {
            let view = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 80.0))
            
            let linePath = UIBezierPath()
            linePath.move(to: CGPoint(x: 83.0, y: 40.0))
            linePath.addLine(to: CGPoint(x: 83.0, y: view.frame.height))
            let lineLayer = CAShapeLayer()
            lineLayer.path = linePath.cgPath
            lineLayer.strokeColor = blue.cgColor
            lineLayer.lineWidth = 3.0
            view.layer.addSublayer(lineLayer)
            
            let circlePath = UIBezierPath(arcCenter: CGPoint(x: 83.0, y: 40.0), radius: 10.0, startAngle: 0.0, endAngle: CGFloat(Double.pi * 2), clockwise: true)
            let circleLayer = CAShapeLayer()
            circleLayer.path = circlePath.cgPath
            circleLayer.strokeColor = blue.cgColor
            circleLayer.fillColor = UIColor.white.cgColor
            circleLayer.lineWidth = 3.0
            view.layer.addSublayer(circleLayer)
            
            let titleLabel = UILabel(frame: CGRect(x: 113.0, y: 20.0, width: view.frame.width-110.0, height: 40.0))
            titleLabel.text = "Genisis"
            titleLabel.font = UIFont.systemFont(ofSize: 18.0, weight: UIFont.Weight.medium)
            view.addSubview(titleLabel)
            
            return view
        }
        return nil
    }
    
    public func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if genisis {
            return 80.0
        } else {
            return 0.0
        }
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "blockCell", for: indexPath) as! BlockTableViewCell
        cell.configure(block: blockchain[indexPath.row], cellMaxHeight: maxCellHeight)
        return cell
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) as? BlockTableViewCell {
            if cell.isExpanded {
                cell.isExpanded = false
            } else {
                cell.isExpanded = true
            }
            tableView.beginUpdates()
            tableView.endUpdates()
        }
    }
    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if let cell = tableView.cellForRow(at: indexPath) as? BlockTableViewCell {
            if cell.isExpanded {
                return self.maxCellHeight
            }
        }
        return self.minCellHeight
    }
}


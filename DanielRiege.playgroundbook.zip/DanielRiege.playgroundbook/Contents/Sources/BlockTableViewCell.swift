//
//  BlockTableViewCell.swift
//  PlaygroundBook
//
//  Created by Daniel Riege on 16.03.19.
//

import UIKit

class BlockTableViewCell: UITableViewCell {

    @IBOutlet weak var checkLabel: UILabel!
    @IBOutlet weak var blockView: UIView!
    @IBOutlet weak var hashLabel: UILabel!
    @IBOutlet weak var fromLabel: UILabel!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var toLabel: UILabel!
    @IBOutlet weak var secondView: UIView!
    
    var isExpanded = false {
        didSet {
            UIView.animate(withDuration: 0.3) {
                if self.isExpanded {
                    self.secondView.alpha = 1.0
                } else {
                    self.secondView.alpha = 0.0
                }
            }
        }
    }
    
    override func prepareForReuse() {
        
    }
    
    func configure(block: [String: String], cellMaxHeight: CGFloat) {
        secondView.alpha = 0.0
        
        checkLabel.text = ""
        hashLabel.text = ""
        fromLabel.text = ""
        amountLabel.text = ""
        toLabel.text = ""
        
        drawLine(height: cellMaxHeight)
        
        for (key, value) in block {
            switch key {
            case "hash": hashLabel.text = "hash: \(value)"
            case "pow": hashLabel.text = hashLabel.text! + "\npow: \(value)"
            case "check":
                if value == "true" {
                    checkLabel.text = ""
                } else if value == "false" {
                    checkLabel.text = "❌"
                }
            case "from": fromLabel.text = value
            case "amount":
                amountLabel.text = value
                if let amount = Double(value) {
                    if amount >= 0 {
                        amountLabel.textColor = UIColor.green
                    } else {
                        amountLabel.textColor = UIColor.black
                    }
                }
                amountLabel.sizeToFit()
            case "to": toLabel.text = value
            default: break
            }
        }
        
        blockView.layer.cornerRadius = 10.0
        
        if fromLabel.text != "" && toLabel.text != "" {
            drawArrow()
        }
    }
    
    func drawLine(height: CGFloat) {
        let topLinePath = UIBezierPath()
        topLinePath.move(to: CGPoint(x: blockView.center.x, y: 0))
        topLinePath.addLine(to: CGPoint(x: blockView.center.x, y: blockView.frame.origin.y))
        let topLineLayer = CAShapeLayer()
        topLineLayer.path = topLinePath.cgPath
        topLineLayer.strokeColor = blue.cgColor
        topLineLayer.lineWidth = 3.0
        
        let bottomLinePath = UIBezierPath()
        bottomLinePath.move(to: CGPoint(x: blockView.center.x,
                                        y: blockView.frame.origin.y + blockView.frame.height))
        bottomLinePath.addLine(to: CGPoint(x: blockView.center.x,
                                           y: height))
        let bottomLineLayer = CAShapeLayer()
        bottomLineLayer.path = bottomLinePath.cgPath
        bottomLineLayer.strokeColor = blue.cgColor
        bottomLineLayer.lineWidth = 3.0
        
        self.layer.addSublayer(topLineLayer)
        self.layer.addSublayer(bottomLineLayer)
    }
    
    var topLineLayer = CAShapeLayer()
    func drawArrow() {
        let topLinePath = UIBezierPath()
        let start = CGPoint(x: secondView.frame.width/2+20, y: fromLabel.frame.origin.y+fromLabel.frame.height)
        let controlPoint = CGPoint(x: secondView.frame.width/2 - amountLabel.frame.width/2,
                                   y: amountLabel.center.y)
        let end = CGPoint(x: secondView.frame.width/2+20, y: toLabel.frame.origin.y)
        
        let pointerLineLength: CGFloat = 14.0
        let arrowAngle = CGFloat(Double.pi / 4)
        let startEndAngle = atan((end.y - controlPoint.y) / (end.x - controlPoint.x)) + ((end.x - controlPoint.x) < 0 ? CGFloat(Double.pi) : 0)
        let arrowLine1 = CGPoint(x: end.x + pointerLineLength * cos(CGFloat(Double.pi) - startEndAngle + arrowAngle),
                                 y: end.y - pointerLineLength * sin(CGFloat(Double.pi) - startEndAngle + arrowAngle))
        let arrowLine2 = CGPoint(x: end.x + pointerLineLength * cos(CGFloat(Double.pi) - startEndAngle - arrowAngle),
                                 y: end.y - pointerLineLength * sin(CGFloat(Double.pi) - startEndAngle - arrowAngle))
        
        topLinePath.move(to: start)
        topLinePath.addQuadCurve(to: end,
                                 controlPoint: controlPoint)
        topLinePath.addLine(to: arrowLine1)
        topLinePath.move(to: end)
        topLinePath.addLine(to: arrowLine2)
        if topLineLayer.superlayer == nil {
            topLineLayer.path = topLinePath.cgPath
            topLineLayer.strokeColor = UIColor.orange.cgColor
            topLineLayer.fillColor = UIColor.clear.cgColor
            topLineLayer.lineWidth = 2.0
            secondView.layer.addSublayer(topLineLayer)
        }
    }
    
}
